#ifndef __LED_H
#define __LED_H

#include "sys.h"



#define LED PAout(8)	// PA8

void LED_Init(void);


#endif




