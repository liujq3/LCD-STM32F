/**
  ******************************************************************************
  * @file    GPIO/IOToggle/stm32f10x_it.c 
  * @author  MCD Application Team
  * @version V3.1.2
  * @date    09/28/2009
  * @brief   Main Interrupt Service Routines.
  *          This file provides template for all exceptions handler and peripherals
  *          interrupt service routine.
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2009 STMicroelectronics</center></h2>
  */

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x_it.h"
#include "stm32f10x.h"
#include "config.h"
#include <stdlib.h>
#include <math.h>

/** @addtogroup STM32F10x_StdPeriph_Examples
  * @{
  */

/** @addtogroup GPIO_IOToggle
  * @{
  */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/******************************************************************************/
/*            Cortex-M3 Processor Exceptions Handlers                         */
/******************************************************************************/

/**
  * @brief  This function handles NMI exception.
  * @param  None
  * @retval None
  */
void NMI_Handler(void)
{
}

/**
  * @brief  This function handles Hard Fault exception.
  * @param  None
  * @retval None
  */
void HardFault_Handler(void)
{
  /* Go to infinite loop when Hard Fault exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles Memory Manage exception.
  * @param  None
  * @retval None
  */
void MemManage_Handler(void)
{
  /* Go to infinite loop when Memory Manage exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles Bus Fault exception.
  * @param  None
  * @retval None
  */
void BusFault_Handler(void)
{
  /* Go to infinite loop when Bus Fault exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles Usage Fault exception.
  * @param  None
  * @retval None
  */
void UsageFault_Handler(void)
{
  /* Go to infinite loop when Usage Fault exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles SVCall exception.
  * @param  None
  * @retval None
  */
void SVC_Handler(void)
{
}

/**
  * @brief  This function handles Debug Monitor exception.
  * @param  None
  * @retval None
  */
void DebugMon_Handler(void)
{
}

/**
  * @brief  This function handles PendSV_Handler exception.
  * @param  None
  * @retval None
  */
void PendSV_Handler(void)
{
}

/**
  * @brief  This function handles SysTick Handler.
  * @param  None
  * @retval None
  */
void SysTick_Handler(void)
{
}

/******************************************************************************/
/*                 STM32F10x Peripherals Interrupt Handlers                   */
/*  Add here the Interrupt Handler for the used peripheral(s) (PPP), for the  */
/*  available peripheral interrupt handler's name please refer to the startup */
/*  file (startup_stm32f10x_xx.s).                                            */
/******************************************************************************/
/************************************************************************
** �� �� ��:   EXTI9_5_IRQHandler
** ��������:   PA8�ⲿ�жϺ��� ���ݼ��
** �������:   ��
** �������:   ��
** �� �� ֵ:   ��	
** ��    ��:   ����
** ��    ��:   2016.10
**------------------------------------------------------------------------
** ��    ��:
** �޸�����:
*************************************************************************/  
void EXTI9_5_IRQHandler(void)
{
  unsigned char i,j;
  static unsigned char index;
  static signed int temp,temp1;
  
  if(EXTI_GetITStatus(EXTI_Line8) != RESET)
  { 
    CapTimeCounter = TIM2->CNT;//������ֵ
    TIM2->CNT = 0;//���ü�����ֵ
    if(T50msCnt > 0)
    {
      CapTime = 50000*T50msCnt + CapTimeCounter;
    }
    else
    {
      CapTime = CapTimeCounter;
    }
    T50msCnt = 0;    
    
    if(CapZeroFlag == TRUE)//������ �ϵ紦��һ�� ���� ͨ����������
    {
      CapTimeTem[CapIndex] = CapTime;
      
      CapIndex ++;
      if(CapIndex >= CN)
      {
        TIM2->CR2 &= CR1_CEN_Reset;//�ر�ʱ��
        TIM2->CNT = 0;//���ü�����ֵ
        TIM2->SR = (uint16_t)~TIM_IT_Update;//�����ʱ��2���жϱ��
        
        CapIndex = 0;
        ChoiseForCap(&CapTimeTem[0],CN); 
        CapSum = 0;
        for(i=RCN;i<(CN-RCN);i++)
        {
          CapSum += CapTimeTem[i];
        }	
        CapZeroCntVal = CapSum/(CN-2*RCN);      
          
        TIM2->CR2 |= CR1_CEN_Set;//����ʱ��
        T50msCnt = 0;
        CapZeroFlag = FALSE;
        CapValZeropfFlag = FALSE;
        
        if(CapZeroCntVal < (C100PFCNTVAL1*10))
        {
          CapMode = PF;
          CapSumCnt = PFCNT;
        }
        else if(CapZeroCntVal < (C100PFCNTVAL1*10000))
        {
          CapMode = NF;
          CapSumCnt = NFCNT;
        } 
        else
        {
          CapMode = UF;
          CapSumCnt = UFCNT;
        }
      }
    }
    else//��������������������
    { 
      CapIndex ++;     
      if(CapIndex > 2)//��ȥ��һ��ֵ
      {
        if(CapIndex == 3)//ȷ�ϵ��ݵĴ�ŷ�Χ
        {
          if(CapTime < (CapZeroCntVal*10))
          {
            CapMode = PF;
            CapSumCnt = PFCNT;
          }
          else if(CapTime < (CapZeroCntVal*10000))
          {
            CapMode = NF;
            CapSumCnt = NFCNT;
          } 
          else
          {
            CapMode = UF;
            CapSumCnt = UFCNT;
          }
          CapTimeTemp = CapTime;
        }
        else//��������ʱ����仯ֵͻȻ�仯���ϴ�  ��ʾ�������ݱ仯��
        {
          if(CapMode < 2)//PF  NF 
          {
            temp = CapTime - CapTimeTemp;
            if(abs(temp) > CapComp[CapMode])//�������²���
            {                       
              CapIndex = 0;
              CapSum = 0;
              T50msCnt = 0;
              EXTI_ClearITPendingBit(EXTI_Line8);  
              TIM2->CR2 &= CR1_CEN_Reset;//�ر�ʱ��
              TIM2->CNT = 0;//���ü�����ֵ
              TIM2->SR = (uint16_t)~TIM_IT_Update;//�����ʱ��2���жϱ��   
              TIM2->CR2 |= CR1_CEN_Set;//����ʱ��
              return;
            }
          }
          CapTimeTemp = CapTime;
        }
        CapSum += CapTime;
      }      
      
      if(CapIndex >= CapSumCnt)
      {
        TIM2->CR2 &= CR1_CEN_Reset;//�ر�ʱ��
        TIM2->CNT = 0;//���ü�����ֵ
        TIM2->SR = (uint16_t)~TIM_IT_Update;//�����ʱ��2���жϱ��
        
        CapIndex = 0;
        CapTimeCheck = CapSum;
        CapSum = 0;
        if(CapValZeropfFlag == TRUE)//�������ֵ
        {
          if(CapMode == PF)
          {
            temp1 = (CapTimeCheck/(C100PFCNTVAL1))*2 - CapValZeropF;
            if(temp1 < 0)
            {
              CapVal = 0;
            }
            else
            {
              CapVal = temp1;
            }
          }
          else if(CapMode == NF)
          {          
            temp = CapTimeCheck - (NFCNT-2)*C100PFCNTVAL2;
            CapTimeCheck = abs(temp);
            CapVal = ((CapTimeCheck/C100PFCNTVAL2)*2)/NFDIV;
          }
          else if(CapMode == UF)
          {                
            temp = CapTimeCheck - (UFCNT-2)*C100PFCNTVAL2;
            CapTimeCheck = abs(temp);
            CapVal = ((CapTimeCheck/C100PFCNTVAL2)*2)/UFDIV;
          }
          if(SysSta == ON)
          {
            //��̬��ʾ
            if(index >= 10)
            {
              index = 0;
              for(j=0;j<10;j++)
              {
                Display_Number_8x16(1,j*8+28,SPA); 
              }
            } 
            Display_Number_8x16(1,index*8+28,19); 
            index++; 
            //��̬��ʾ            
            Display_CapVal();
          }
        }
        else//�����·���ϵ�pf����ֵ 
        {
          CapValZeropF = (CapTimeCheck/(C100PFCNTVAL1))*2;
          CapValZeropfFlag = TRUE;
        }
        TIM2->CR2 |= CR1_CEN_Set;//����ʱ��
        T50msCnt = 0;
      } 
    }  
    EXTI_ClearITPendingBit(EXTI_Line8);    
  }
}
/************************************************************************
** �� �� ��:   TIM2_IRQHandler
** ��������:   ��ʱ��2�жϴ������� ���
** �������:   ��
** �������:   ��
** �� �� ֵ:   ��	
** ��    ��:   ����
** ��    ��:   2016.10
**------------------------------------------------------------------------
** ��    ��:
** �޸�����:
*************************************************************************/  
void TIM2_IRQHandler(void)
{  
  if(TIM_GetITStatus(TIM2,TIM_IT_Update) != RESET)
  {
    T50msCnt ++;
    TIM_ClearITPendingBit(TIM2,TIM_IT_Update);
  } 
}
/************************************************************************
** �� �� ��:   TIM1_UP_IRQHandler
** ��������:   ��ʱ��1�жϴ������� ���
** �������:   ��
** �������:   ��
** �� �� ֵ:   ��	
** ��    ��:   ����
** ��    ��:   2016.10
**------------------------------------------------------------------------
** ��    ��:
** �޸�����:
*************************************************************************/  
void TIM1_UP_IRQHandler(void)
{  
  if(TIM_GetITStatus(TIM1,TIM_IT_Update) != RESET)
  {
    TIM_ClearITPendingBit(TIM1,TIM_IT_Update);
  } 
}
/************************************************************************
** �� �� ��:   DMA1_Channel1_IRQHandler
** ��������:   DMA1 ͨ��1�ж�  ADC1 DMA�ж�  8·ADC
** �������:   ��
** �������:   ��
** �� �� ֵ:   ��	
** ��    ��:   ����
** ��    ��:   2016.10
**------------------------------------------------------------------------
** ��    ��:
** �޸�����:
*************************************************************************/ 
void DMA1_Channel1_IRQHandler(void)
{
  unsigned char i,k;
  //static unsigned short val[2];
  
  if(DMA_GetFlagStatus(DMA1_IT_TC1) != RESET)
  {     
    DMA_ClearFlag(DMA1_IT_TC1);    
    
    for(k=0;k<2;k++)
    {
      AdcVal[k][AdcIndex] =  ADC1ConvertedValue[k];
    }
    
    AdcIndex ++;
    if(AdcIndex >= N)
    {	
      AdcIndex = 0;
      
      for(k=0;k<2;k++)
      {
        Choise(&AdcVal[k][0],N);      
        ADCSum = 0;
        for(i=RN;i<(N-RN);i++)
        {
          ADCSum += AdcVal[k][i];
        }	
        //val[k] = ADCSum/(N-2*RN);
      }
      //2·ADͨ��DMA��ʽ�ɼ��˲�������	
      //CHIadcVal[0] = val[1];
      //CHIadcVal[1] = val[0];
    }
  }
}
//void EXTI9_5_IRQHandler(void)
//{
//  unsigned char i;
//  
//  if(EXTI_GetITStatus(EXTI_Line8) != RESET)
//  {  
//    CapTimeCounter = TIM2->CNT;//������ֵ
//    TIM2->CNT = 0;//���ü�����ֵ
//    if(T50msCnt > 0)
//    {
//      CapTime = 50000*T50msCnt + CapTimeCounter;
//    }
//    else
//    {
//      CapTime = CapTimeCounter;
//    }
//    T50msCnt = 0;
//    CapTimeTem[CapIndex] = CapTime;
//    CapIndex ++;
//    if(CapIndex >= CN)
//    {
//      TIM2->CR2 &= CR1_CEN_Reset;//�ر�ʱ��
//      TIM2->CNT = 0;//���ü�����ֵ
//      TIM2->SR = (uint16_t)~TIM_IT_Update;//�����ʱ��2���жϱ��
//      
//      CapIndex = 0;
//      ChoiseForCap(&CapTimeTem[0],CN); 
//      CapSum = 0;
//      for(i=RCN;i<(CN-RCN);i++)
//      {
//        CapSum += CapTimeTem[i];
//      }	
//      CapTimeCheckx100 = CapSum;
//      CapTimeCheck = CapSum/(CN-2*RCN);
//      
//      TIM2->CR2 |= CR1_CEN_Set;//����ʱ��
//      T50msCnt = 0;
//    }
//    EXTI_ClearITPendingBit(EXTI_Line8);    
//  }
//}
/*
void EXTI0_IRQHandler(void)
{
  
  if(EXTI_GetITStatus(SELECT_EXTI_LINE) != RESET)
  {
    select_button=TRUE;    
    // Clear KEY_BUTTON_EXTI_LINE pending bit 
    EXTI_ClearITPendingBit(SELECT_EXTI_LINE);
  }
  else
    select_button=FALSE;
}


void EXTI4_IRQHandler(void)
{
  
  if(EXTI_GetITStatus(UP_EXTI_LINE) != RESET)
  {
    select_button=TRUE;    
    // Clear KEY_BUTTON_EXTI_LINE pending bit
    EXTI_ClearITPendingBit(UP_EXTI_LINE);
  }
  else
    select_button=FALSE;
}
*/
/**
  * @brief  This function handles PPP interrupt request.
  * @param  None
  * @retval None
  */
/*void PPP_IRQHandler(void)
{
}*/

/**
  * @}
  */

/**
  * @}
  */

/******************* (C) COPYRIGHT 2009 STMicroelectronics *****END OF FILE****/
