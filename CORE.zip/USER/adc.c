#include "stm32f10x.h"
#include "config.h"

#define ADC1_DR_Address    ((uint32_t)0x4001244C)
unsigned short ADC1ConvertedValue[2];//12BIT 4096

unsigned short AdcVal[2][N];
unsigned int ADCSum;
unsigned char AdcIndex = 0;

/************************************************************************
** �� �� ��:   ADC_Config
** ��������:   ADת������
** �������:   ��
** �������:   ��
** �� �� ֵ:   ��
** ��    ��:   ����
** ��    ��:   2016.10
**------------------------------------------------------------------------
** ��    ��:
** �޸�����:
*************************************************************************/  
void ADCInit_Config(void)
{
  ADC_InitTypeDef ADC_InitStructure;
  DMA_InitTypeDef DMA_InitStructure;
  GPIO_InitTypeDef GPIO_InitStructure;
  
  //ADC����˿����� PA1-2
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
  
  // DMA1 channel1 configuration ----------------------------------------------
  DMA_DeInit(DMA1_Channel1);
  DMA_InitStructure.DMA_PeripheralBaseAddr = ADC1_DR_Address;
  DMA_InitStructure.DMA_MemoryBaseAddr = (uint32_t)&ADC1ConvertedValue;
  DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralSRC;
  DMA_InitStructure.DMA_BufferSize = 2;
  DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
  DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
  DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
  DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;
  DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;
  DMA_InitStructure.DMA_Priority = DMA_Priority_High;
  DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
  DMA_Init(DMA1_Channel1, &DMA_InitStructure);  
  // Enable DMA1 channel1 
  DMA_Cmd(DMA1_Channel1, ENABLE);
  
  // ADC1 configuration ------------------------------------------------------
  ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;
  ADC_InitStructure.ADC_ScanConvMode = ENABLE;
  ADC_InitStructure.ADC_ContinuousConvMode = ENABLE;
  ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;
  ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
  ADC_InitStructure.ADC_NbrOfChannel = 2;
  ADC_Init(ADC1, &ADC_InitStructure);
  // ADC1 regular channels configuration 
  ADC_RegularChannelConfig(ADC1, ADC_Channel_0, 1, ADC_SampleTime_239Cycles5);  
  ADC_RegularChannelConfig(ADC1, ADC_Channel_1, 2, ADC_SampleTime_239Cycles5); 
  // Enable ADC1 DMA 
  ADC_DMACmd(ADC1, ENABLE);  
  // Enable ADC1 
  ADC_Cmd(ADC1, ENABLE);
  // Enable ADC1 reset calibaration register    
  ADC_ResetCalibration(ADC1);
  // Check the end of ADC1 reset calibration register 
  while(ADC_GetResetCalibrationStatus(ADC1));
  // Start ADC1 calibaration 
  ADC_StartCalibration(ADC1);
  // Check the end of ADC1 calibration 
  while(ADC_GetCalibrationStatus(ADC1));  
  // Start ADC1 Software Conversion  
  ADC_SoftwareStartConvCmd(ADC1, ENABLE);  
  // Enable DMA Channel1 complete transfer interrupt  
  DMA_ITConfig(DMA1_Channel1, DMA_IT_TC, ENABLE);    
}
/************************************************************************
** �� �� ��:   Choise
** ��������:   ѡ������ ����
** �������:   a �����ַ  n���鳤��
** �������:   ��
** �� �� ֵ:   ��	
** ��    ��:   ����
** ��    ��:   2016.10
**------------------------------------------------------------------------
** ��    ��:
** �޸�����:
*************************************************************************/
void Choise(unsigned short *a,unsigned short n) 
{ 
  unsigned short i,j,k,temp; 
  
  for(i=0;i<n-1;i++) 
  {
    k = i; /*���ǺŸ�ֵ*/     
    for(j=i+1;j<n;j++) 
    {
      if(a[k] > a[j]) 
      {
        k = j; /*��k����ָ����СԪ��*/ 
      }
    }    
    if(i != k) 
    { 
      /*��k!=i�ǲŽ���������a[i]��Ϊ��С*/     
      temp = a[i];       
      a[i] = a[k];      
      a[k] = temp;
    } 
  } 
}
