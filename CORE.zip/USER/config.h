/* define ------------------------------------------------------------------*/

#define CLOCK 72/8 //ʱ��=8M

#define NOP asm("nop")
#define CLWDT() IWDG_ReloadCounter()

#define TRUE  1
#define FALSE 0
#define NOM 0

#define OFF    0
#define ON     1
#define HOLD   2


//Lcd�ӿ�
#define Lcd_RS_Pin       GPIO_Pin_6  //PA6
#define Lcd_REST_Pin     GPIO_Pin_7  //PA7
#define Lcd_CS_Pin       GPIO_Pin_0  //PB0
#define Lcd_SDA_Pin      GPIO_Pin_1  //PB1
#define Lcd_SCLK_Pin     GPIO_Pin_10 //PB10
#define Lcd_RS_L()       GPIOA->BRR =Lcd_RS_Pin  
#define Lcd_RS_H()       GPIOA->BSRR=Lcd_RS_Pin  
#define Lcd_REST_L()     GPIOA->BRR =Lcd_REST_Pin  
#define Lcd_REST_H()     GPIOA->BSRR=Lcd_REST_Pin  
#define Lcd_CS_L()       GPIOB->BRR =Lcd_CS_Pin  
#define Lcd_CS_H()       GPIOB->BSRR=Lcd_CS_Pin  
#define Lcd_SDA_L()      GPIOB->BRR =Lcd_SDA_Pin  
#define Lcd_SDA_H()      GPIOB->BSRR=Lcd_SDA_Pin   
#define Lcd_SCLK_L()     GPIOB->BRR =Lcd_SCLK_Pin  
#define Lcd_SCLK_H()     GPIOB->BSRR=Lcd_SCLK_Pin 

#define SPA    10
#define DOT    11
#define PDS    12
#define NDS    13
#define UDS    14
#define FDS    15

void Initial_Lcd(void);
void Clear_Lcd(unsigned char flag);
void Transfer_Data_Lcd(unsigned char data);
void Transfer_Command_Lcd(unsigned char data);
void DisPlayGraphic(unsigned char *dp);
void Lcd_Address(unsigned char page,unsigned char column);
void Display_Graphic_16x16(unsigned char page,unsigned char column,unsigned char *dp);
void Display_Graphic_8x16(unsigned char page,unsigned char column,unsigned char *dp);
void Display_Graphic_5x7(unsigned char page,unsigned char column,unsigned char *dp);
void Display_Number_8x16(unsigned char page,unsigned char column,unsigned char num);
void Display_CapVal(void);
extern unsigned char Graphic1[];
extern unsigned char Graphic2[];
extern unsigned char Hold[];

//��Դ���ƽӿ�
#define Power_Ctrl_Pin     GPIO_Pin_9 //PA9
#define Power_On()         GPIOA->BSRR=Power_Ctrl_Pin  
#define Power_Off()        GPIOA->BRR =Power_Ctrl_Pin 
//��Դ�������
#define Power_Key_Pin      GPIO_Pin_6 //PC6
#define Power_Key_Sta()    !GPIO_ReadInputDataBit(GPIOC,Power_Key_Pin)
//����1-4 ��·���Ϸ���������
#define KEYDLYCNT  20
#define KEY_NULL  0
#define KEY_1     1
#define KEY_2     2
#define KEY_3     3
#define KEY_4     4
#define KEY_P     5
#define Key_1_Pin          GPIO_Pin_15 //PB15
#define Key_2_Pin          GPIO_Pin_14 //PB14
#define Key_3_Pin          GPIO_Pin_13 //PB13
#define Key_4_Pin          GPIO_Pin_12 //PB12
#define Key_1_Sta()        !GPIO_ReadInputDataBit(GPIOB,Key_1_Pin)
#define Key_2_Sta()        !GPIO_ReadInputDataBit(GPIOB,Key_2_Pin)
#define Key_3_Sta()        !GPIO_ReadInputDataBit(GPIOB,Key_3_Pin)
#define Key_4_Sta()        !GPIO_ReadInputDataBit(GPIOB,Key_4_Pin)
void KeyScan(void);

//���ݼ���
#define C_check_Pin        GPIO_Pin_8 //PA8
#define C_check_Sta()      (GPIOA->IDR&C_check_Pin)

#define CR1_CEN_Set                 ((uint16_t)0x0001)
#define CR1_CEN_Reset               ((uint16_t)0x03FE)


//��ʱ����
void Delay_us(unsigned int us);
void Delay_ms(unsigned int ms);

void NVIC_ConfigurationInit(void);

//TIM���
void TIM1_Init(void);
void TIM2_Init(void);
void TIM3_Init(void);
void TIM5_InitStructurePWM(void);

//WDT���
void WatchDogInit(void);


//ADC
#define N 15
#define RN 5  
extern unsigned short AdcVal[2][N];
extern unsigned int ADCSum;
extern unsigned char AdcIndex;
extern unsigned short ADC1ConvertedValue[2];
void ADCInit_Config(void);
void Choise(unsigned short *a,unsigned short n);

#define CLI()      __set_PRIMASK(1)  //�������ж�
#define SEI()      __set_PRIMASK(0)  //ʹ�����ж�

void AOutPut_Init(void);
void OutPutDacVal(unsigned char ch,unsigned char per);

//���ݲ������
#define PF  0
#define NF  1
#define UF  2

#define PFCNT 5002
#define NFCNT 52
#define UFCNT 7
#define NFDIV 1
#define UFDIV 10

//#define PFCNT 5002
//#define NFCNT 502
//#define UFCNT 52
//#define NFDIV 10
//#define UFDIV 100


#define C100PFCNTVAL1  84
#define C100PFCNTVAL2  78

#define CN 21
#define RCN 1  
extern unsigned char SysSta;
extern unsigned short Blpwmval;
extern unsigned int CapTimeCounter;
extern unsigned int CapTime;
extern unsigned int CapTimeTemp;
extern unsigned int CapTimeCheck;
extern unsigned int CapTimeCheckTem;
extern unsigned short T50msCnt;
extern unsigned int CapSum;
extern unsigned int CapTimeTem[CN];
extern unsigned short CapIndex;
extern unsigned char CapZeroFlag;
extern unsigned char CapMode;
extern unsigned int CapZeroCntVal;
extern unsigned int CapVal;
extern unsigned int CapValZeropF;
extern unsigned int CapValZeropfFlag;
extern unsigned short CapSumCnt;
extern unsigned int CapComp[3];
void ChoiseForCap(unsigned int *a,unsigned short n);
