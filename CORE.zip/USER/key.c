
#include "stm32f10x.h"
#include "config.h"

unsigned char KeyFlag;
/************************************************************************
** �� �� ��:   KeyScan
** ��������:   ����ɨ�躯��
** �������:   ��
** �������:   ��
** �� �� ֵ:   ��
** ��    ��:   ����
** ��    ��:   2016.10
**------------------------------------------------------------------------
** ��    ��:
** �޸�����:
*************************************************************************/  
void KeyScan(void)
{
  if(Power_Key_Sta())//��Դ����
  {   
    if(SysSta == ON)
    {      
      Delay_ms(KEYDLYCNT);
    }
    else 
    {
      Delay_ms(400);
    }
    while(Power_Key_Sta())
    {
      CLWDT();
      if(KeyFlag == KEY_NULL)
      { 
        KeyFlag = KEY_P;   
        if(SysSta != OFF)
        {      
          Power_Off(); 
          SysSta = OFF;
          CLI();
          Clear_Lcd(0);
          while(1)
          {
            CLWDT();
          }
        }
        else if(SysSta == OFF)
        {
          Power_On();          
          
          DisPlayGraphic(Graphic1);
          Delay_ms(1000);
          DisPlayGraphic(Graphic2);
          Delay_ms(1000);
          Clear_Lcd(0);
          SysSta = ON;
          NVIC_ConfigurationInit();
        }
      }
    }
  }
  if(Key_1_Sta())//����1 ����+
  {
    Delay_ms(KEYDLYCNT);
    while(Key_1_Sta())
    {
      CLWDT();
      if(KeyFlag == KEY_NULL)
      {        
        Blpwmval += 80;
        if(Blpwmval > 800)
        {
          Blpwmval = 800;
        }
        TIM5->CCR3 = Blpwmval;
        KeyFlag = KEY_1;
      }
    }
  }
  if(Key_2_Sta())//����2  ���� ��
  {
    Delay_ms(KEYDLYCNT);
    while(Key_2_Sta())
    {
      CLWDT();
      if(KeyFlag == KEY_NULL)
      {
        Blpwmval = 0;
        TIM5->CCR3 = Blpwmval;
        KeyFlag = KEY_2;
      }
    }
  }
  if(Key_3_Sta())//����3 ����
  {
    Delay_ms(KEYDLYCNT);
    while(Key_3_Sta())
    {
      CLWDT();
      if(KeyFlag == KEY_NULL)
      {
        CLI();
        Display_Number_8x16(1,111,SPA);
        Display_Number_8x16(1,119,SPA);
        SysSta = ON;
        CapZeroFlag = TRUE;
        T50msCnt = 0;
        CapTime = 0;
        CapIndex = 0;
        Delay_ms(300);
        SEI();
        
        KeyFlag = KEY_3;
      }
    }
  }
  if(Key_4_Sta())//����4 ����
  {
    Delay_ms(KEYDLYCNT);
    while(Key_4_Sta())
    {
      CLWDT();
      if(KeyFlag == KEY_NULL)
      {
        if(SysSta == ON)
        {
          SysSta = HOLD;
          Display_Graphic_16x16(1,111,Hold);
        }
        else if(SysSta == HOLD)
        {
          Display_Number_8x16(1,111,SPA);
          Display_Number_8x16(1,119,SPA);
          SysSta = ON;
        }
        KeyFlag = KEY_4;
      }
    }
  }
  KeyFlag = KEY_NULL;
}
