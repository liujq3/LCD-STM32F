
#include "stm32f10x.h"
#include "config.h"
unsigned char Graphic1[] = {
/*--  ����x�߶�=128x32  --*/
0xFF,0x01,0xFD,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,
0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,
0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x85,0x85,0x05,
0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,
0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x85,0x85,0x05,
0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,
0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,
0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0xFD,0x01,0xFF,
0xFF,0x00,0xFF,0x00,0x00,0x00,0x08,0x78,0xF8,0x88,0x08,0x0B,0x0F,0x0C,0x08,0xE8,
0xE8,0x08,0x08,0x00,0x00,0x10,0x10,0xF8,0xFE,0x17,0x11,0x13,0xF6,0xEC,0x18,0x10,
0xFE,0xFE,0x00,0xFF,0xFF,0x00,0x00,0xFC,0xFC,0x26,0x22,0x22,0x22,0xFF,0xFF,0x22,
0x22,0x22,0x26,0xFC,0xFC,0x00,0x00,0x00,0x40,0x41,0x41,0x41,0x41,0x41,0x51,0x79,
0xED,0xC5,0x47,0x43,0x41,0x40,0x40,0x00,0x00,0x1C,0x9F,0x97,0x94,0xFF,0xFF,0x94,
0x94,0x94,0x10,0xFE,0xFE,0x00,0xFF,0xFF,0x00,0x00,0x60,0xF8,0xFF,0x47,0x78,0x3F,
0x07,0xFE,0xFE,0x22,0x22,0x22,0x22,0x22,0x02,0x00,0x00,0x02,0x22,0x22,0x2F,0x2F,
0x22,0xE2,0xE2,0x22,0x27,0x27,0x22,0xE2,0xE2,0x02,0x00,0x00,0x00,0xFF,0x00,0xFF,
0xFF,0x00,0xFF,0x00,0x00,0x20,0x20,0x20,0x2F,0x3F,0x30,0x20,0x20,0x20,0x30,0x3F,
0x2F,0x20,0x20,0x20,0x00,0x00,0x00,0x1F,0x3F,0x20,0x22,0x22,0x23,0x23,0x3C,0x1C,
0x27,0x27,0x20,0x3F,0x1F,0x00,0x00,0x03,0x03,0x02,0x02,0x02,0x02,0x3F,0x3F,0x22,
0x22,0x22,0x22,0x23,0x3B,0x18,0x00,0x00,0x00,0x00,0x10,0x10,0x30,0x20,0x20,0x20,
0x31,0x1F,0x0E,0x00,0x00,0x00,0x00,0x00,0x00,0x3F,0x3F,0x00,0x00,0x3F,0x3F,0x20,
0x20,0x3F,0x1F,0x27,0x27,0x20,0x3F,0x1F,0x00,0x00,0x00,0x1F,0x1F,0x00,0x00,0x00,
0x00,0x3F,0x3F,0x04,0x04,0x04,0x04,0x04,0x04,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x3F,0x3F,0x08,0x18,0x10,0x10,0x1F,0x0F,0x00,0x00,0x00,0x00,0xFF,0x00,0xFF,
0xFF,0x80,0xBF,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,
0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,
0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,
0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,
0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,
0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,
0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,
0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xBF,0x80,0xFF
};
unsigned char Graphic2[] = {
/*--  ����x�߶�=128x32  --*/
0xFF,0x01,0xFD,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,
0x85,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x85,
0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,
0x05,0x05,0x05,0x05,0x05,0x05,0x85,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,
0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x85,0x05,0x05,
0x05,0x85,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,
0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,
0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0x05,0xFD,0x01,0xFF,
0xFF,0x00,0xFF,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xFC,0x44,0x44,0x44,0x44,
0xFF,0x44,0x44,0x44,0x44,0xFC,0x00,0x00,0x00,0x08,0x06,0x22,0x12,0x8A,0x42,0x22,
0x13,0x22,0x42,0x8A,0x12,0x22,0x0A,0x06,0x00,0x08,0x30,0x01,0xC6,0x00,0xFF,0x01,
0xF9,0x01,0xFF,0x00,0xFC,0x00,0xFF,0x00,0x00,0x10,0x10,0x10,0xDF,0x55,0x55,0x55,
0xD5,0x55,0x55,0x55,0xDF,0x10,0x10,0x10,0x00,0x80,0x40,0x30,0xFC,0x03,0x00,0x0E,
0x70,0x80,0x03,0x80,0x70,0x0F,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x80,0x80,0x80,0x80,0x80,0xF8,0xF8,0x00,0xF8,0xF8,0x80,0x80,0x80,0x80,
0x80,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xFF,0x00,0xFF,
0xFF,0x00,0xFF,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x0F,0x04,0x04,0x04,0x04,
0x3F,0x44,0x44,0x44,0x44,0x4F,0x40,0x78,0x00,0x02,0x02,0x01,0x7F,0x22,0x22,0x22,
0x22,0x22,0x22,0x22,0x7F,0x01,0x02,0x02,0x00,0x02,0x02,0x3F,0x00,0x40,0x23,0x18,
0x07,0x08,0x13,0x00,0x23,0x40,0x3F,0x00,0x00,0x00,0x40,0x40,0x57,0x55,0x55,0x55,
0x7F,0x55,0x55,0x55,0x57,0x40,0x40,0x00,0x00,0x00,0x00,0x00,0x7F,0x00,0x40,0x20,
0x10,0x09,0x06,0x09,0x10,0x20,0x40,0x40,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x0F,0x0F,0x00,0x0F,0x0F,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xFF,0x00,0xFF,
0xFF,0x80,0xBF,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,
0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,
0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,
0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,
0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,
0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,
0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,
0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xA0,0xBF,0x80,0xFF
};
unsigned char Number[] = {//0123456789 .pnuFCap
/*--  ����:  0  --*/
/*--  ����12;  �������¶�Ӧ�ĵ���Ϊ����x��=8x16   --*/
0x00,0xE0,0x10,0x08,0x08,0x10,0xE0,0x00,0x00,0x0F,0x10,0x20,0x20,0x10,0x0F,0x00,

/*--  ����:  1  --*/
/*--  ����12;  �������¶�Ӧ�ĵ���Ϊ����x��=8x16   --*/
0x00,0x10,0x10,0xF8,0x00,0x00,0x00,0x00,0x00,0x20,0x20,0x3F,0x20,0x20,0x00,0x00,

/*--  ����:  2  --*/
/*--  ����12;  �������¶�Ӧ�ĵ���Ϊ����x��=8x16   --*/
0x00,0x70,0x08,0x08,0x08,0x88,0x70,0x00,0x00,0x30,0x28,0x24,0x22,0x21,0x30,0x00,

/*--  ����:  3  --*/
/*--  ����12;  �������¶�Ӧ�ĵ���Ϊ����x��=8x16   --*/
0x00,0x30,0x08,0x88,0x88,0x48,0x30,0x00,0x00,0x18,0x20,0x20,0x20,0x11,0x0E,0x00,

/*--  ����:  4  --*/
/*--  ����12;  �������¶�Ӧ�ĵ���Ϊ����x��=8x16   --*/
0x00,0x00,0xC0,0x20,0x10,0xF8,0x00,0x00,0x00,0x07,0x04,0x24,0x24,0x3F,0x24,0x00,

/*--  ����:  5  --*/
/*--  ����12;  �������¶�Ӧ�ĵ���Ϊ����x��=8x16   --*/
0x00,0xF8,0x08,0x88,0x88,0x08,0x08,0x00,0x00,0x19,0x21,0x20,0x20,0x11,0x0E,0x00,

/*--  ����:  6  --*/
/*--  ����12;  �������¶�Ӧ�ĵ���Ϊ����x��=8x16   --*/
0x00,0xE0,0x10,0x88,0x88,0x18,0x00,0x00,0x00,0x0F,0x11,0x20,0x20,0x11,0x0E,0x00,

/*--  ����:  7  --*/
/*--  ����12;  �������¶�Ӧ�ĵ���Ϊ����x��=8x16   --*/
0x00,0x38,0x08,0x08,0xC8,0x38,0x08,0x00,0x00,0x00,0x00,0x3F,0x00,0x00,0x00,0x00,

/*--  ����:  8  --*/
/*--  ����12;  �������¶�Ӧ�ĵ���Ϊ����x��=8x16   --*/
0x00,0x70,0x88,0x08,0x08,0x88,0x70,0x00,0x00,0x1C,0x22,0x21,0x21,0x22,0x1C,0x00,

/*--  ����:  9  --*/
/*--  ����12;  �������¶�Ӧ�ĵ���Ϊ����x��=8x16   --*/
0x00,0xE0,0x10,0x08,0x08,0x10,0xE0,0x00,0x00,0x00,0x31,0x22,0x22,0x11,0x0F,0x00,

/*--  ����:     --*/
/*--  ����12;  �������¶�Ӧ�ĵ���Ϊ����x��=8x16   --*/
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,

/*--  ����:  .  --*/
/*--  ����12;  �������¶�Ӧ�ĵ���Ϊ����x��=8x16   --*/
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x30,0x30,0x00,0x00,0x00,0x00,0x00,

/*--  ����:  p  --*/
/*--  ����12;  �������¶�Ӧ�ĵ���Ϊ����x��=8x16   --*/
0x80,0x80,0x00,0x80,0x80,0x00,0x00,0x00,0x80,0xFF,0xA1,0x20,0x20,0x11,0x0E,0x00,

/*--  ����:  n  --*/
/*--  ����12;  �������¶�Ӧ�ĵ���Ϊ����x��=8x16   --*/
0x80,0x80,0x00,0x80,0x80,0x80,0x00,0x00,0x20,0x3F,0x21,0x00,0x00,0x20,0x3F,0x20,

/*--  ����:  u  --*/
/*--  ����12;  �������¶�Ӧ�ĵ���Ϊ����x��=8x16   --*/
0x80,0x80,0x00,0x00,0x00,0x80,0x80,0x00,0x00,0x1F,0x20,0x20,0x20,0x10,0x3F,0x20,

/*--  ����:  F  --*/
/*--  ����12;  �������¶�Ӧ�ĵ���Ϊ����x��=8x16   --*/
0x08,0xF8,0x88,0x88,0xE8,0x08,0x10,0x00,0x20,0x3F,0x20,0x00,0x03,0x00,0x00,0x00,

/*--  ����:  C  --*/
/*--  ����12;  �������¶�Ӧ�ĵ���Ϊ����x��=8x16   --*/
0xC0,0x30,0x08,0x08,0x08,0x08,0x38,0x00,0x07,0x18,0x20,0x20,0x20,0x10,0x08,0x00,

/*--  ����:  a  --*/
/*--  ����12;  �������¶�Ӧ�ĵ���Ϊ����x��=8x16   --*/
0x00,0x00,0x80,0x80,0x80,0x80,0x00,0x00,0x00,0x19,0x24,0x22,0x22,0x22,0x3F,0x20,

/*--  ����:  p  --*/
/*--  ����12;  �������¶�Ӧ�ĵ���Ϊ����x��=8x16   --*/
0x80,0x80,0x00,0x80,0x80,0x00,0x00,0x00,0x80,0xFF,0xA1,0x20,0x20,0x11,0x0E,0x00,

/*--  ������һ��ͼ��F:\�����̳ǵ���������\�ͳɱ����ݲ�����\����\fuhao.bmp  --*/
/*--  ����x�߶�=8x16  --*/
0x00,0xC0,0xC0,0xC0,0xC0,0xC0,0xC0,0x00,0x00,0x1F,0x1F,0x1F,0x1F,0x1F,0x1F,0x00
};
unsigned char Hold[] = {
/*--  ����x�߶�=16x16  --*/
0x00,0xFE,0x02,0x02,0xFA,0xFA,0xC2,0xC2,0xC2,0xC2,0xFA,0xFA,0x02,0x02,0xFE,0x00,
0x00,0x7F,0x40,0x40,0x5F,0x5F,0x40,0x40,0x40,0x40,0x5F,0x5F,0x40,0x40,0x7F,0x00
};
/************************************************************************
** �� �� ��:   Display_CapVal
** ��������:   ��ʾ�����ĵ���ֵ
** �������:   ��
** �������:   ��
** �� �� ֵ:   ��	
** ��    ��:   ����
** ��    ��:   2016.10
*************************************************************************/ 
void Display_CapVal(void)
{
  unsigned char temp,i,adx,adj;
  
  for(i=0;i<16;i++)
  {
    Display_Number_8x16(3,i*8,SPA);
  }
  
  i = 0;
  adj = 0;
  adx = i*8 + adj;
  i++;
  Display_Number_8x16(1,adx,16); //C 
  adx = i*8 + adj;
  i++;
  Display_Number_8x16(1,adx,17); //a 
  adx = i*8 + adj;
  i++; 
  Display_Number_8x16(1,adx,18); //p  
  
  if(CapMode == PF)
  {
    if((CapVal/1000000) != 0)
    {
      i = 1;
      adj = 4;
      temp = CapVal/1000000;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      temp = (CapVal%1000000)/100000;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      temp = (CapVal%100000)/10000;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      temp = (CapVal%10000)/1000;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      temp = (CapVal%1000)/100;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      i = 1;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,DOT);
      temp = (CapVal%100)/10;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      temp = CapVal%10;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,SPA);
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,PDS);
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,FDS);
    }
    else if((CapVal/100000) != 0)
    {
      i = 2;
      adj = 0;
      temp = (CapVal%1000000)/100000;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      temp = (CapVal%100000)/10000;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      temp = (CapVal%10000)/1000;
      Display_Number_8x16(3,adx,temp);
      temp = (CapVal%1000)/100;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,DOT);
      temp = (CapVal%100)/10;
      Display_Number_8x16(3,adx,temp);
      temp = CapVal%10;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,SPA);
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,PDS);
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,FDS);
    }
    else if((CapVal/10000) != 0)
    {
      i = 2;
      adj = 4;
      temp = (CapVal%100000)/10000;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      temp = (CapVal%10000)/1000;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      temp = (CapVal%1000)/100;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,DOT);
      temp = (CapVal%100)/10;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      temp = CapVal%10;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,SPA);
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,PDS);
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,FDS);
    }
    else if((CapVal/1000) != 0)
    {
      i = 3;
      adj = 0;
      temp = (CapVal%10000)/1000;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      temp = (CapVal%1000)/100;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,DOT);
      temp = (CapVal%100)/10;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      temp = CapVal%10;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,SPA);
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,PDS);
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,FDS);
    }
    else
    {
      i = 3;
      adj = 4;
      temp = (CapVal%1000)/100;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,DOT);
      temp = (CapVal%100)/10;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      temp = CapVal%10;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,SPA);
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,PDS);
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,FDS);
    }
  }
  else if(CapMode == NF)
  {
    if((CapVal/1000000) != 0)
    {
      i = 1;
      adj = 4;
      temp = CapVal/1000000;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      temp = (CapVal%1000000)/100000;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      temp = (CapVal%100000)/10000;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      temp = (CapVal%10000)/1000;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,DOT);
      temp = (CapVal%1000)/100;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      temp = (CapVal%100)/10;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      temp = CapVal%10;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,SPA);
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,NDS);
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,FDS);
    }
    else if((CapVal/100000) != 0)
    {
      i = 2;
      adj = 0;
      temp = (CapVal%1000000)/100000;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      temp = (CapVal%100000)/10000;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      temp = (CapVal%10000)/1000;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,DOT);
      temp = (CapVal%1000)/100;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      temp = (CapVal%100)/10;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      temp = CapVal%10;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,SPA);
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,NDS);
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,FDS);
    }
    else if((CapVal/10000) != 0)
    {
      i = 2;
      adj = 4;
      temp = (CapVal%100000)/10000;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      temp = (CapVal%10000)/1000;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,DOT);
      temp = (CapVal%1000)/100;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      temp = (CapVal%100)/10;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      temp = CapVal%10;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,SPA);
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,NDS);
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,FDS);
    }
    else 
    {
      i = 3;
      adj = 0;
      temp = (CapVal%10000)/1000;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,DOT);
      temp = (CapVal%1000)/100;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      temp = (CapVal%100)/10;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      temp = CapVal%10;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,SPA);
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,NDS);
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,FDS);
    }
  }
  else if(CapMode == UF)
  {
    if((CapVal/1000000) != 0)
    {
      i = 1;
      adj = 4;
      temp = CapVal/1000000;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      temp = (CapVal%1000000)/100000;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      temp = (CapVal%100000)/10000;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,DOT);
      temp = (CapVal%10000)/1000;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      temp = (CapVal%1000)/100;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      temp = (CapVal%100)/10;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      temp = CapVal%10;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,SPA);
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,UDS);
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,FDS);
    }
    else if((CapVal/100000) != 0)
    {
      i = 2;
      adj = 0;
      temp = (CapVal%1000000)/100000;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      temp = (CapVal%100000)/10000;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,DOT);
      temp = (CapVal%10000)/1000;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      temp = (CapVal%1000)/100;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      temp = (CapVal%100)/10;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      temp = CapVal%10;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,SPA);
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,UDS);
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,FDS);
    }
    else
    {
      i = 2;
      adj = 4;
      temp = (CapVal%100000)/10000;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,DOT);
      temp = (CapVal%10000)/1000;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      temp = (CapVal%1000)/100;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      temp = (CapVal%100)/10;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      temp = CapVal%10;
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,temp);
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,SPA);
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,UDS);
      adx = i*8 + adj;
      i++;
      Display_Number_8x16(3,adx,FDS);
    }
  }
}
/************************************************************************
** �� �� ��:   Initial_Lcd
** ��������:   LCD��ʼ��
** �������:   ��
** �������:   ��
** �� �� ֵ:   ��	
** ��    ��:   ����
** ��    ��:   2016.10
*************************************************************************/ 
void Initial_Lcd(void)
{
  Lcd_CS_L();
  Lcd_REST_L(); 
  Delay_ms(20);
  Lcd_REST_H();
  Transfer_Command_Lcd(0xE2); /*����λ*/
  Transfer_Command_Lcd(0x2C); /*��ѹ���� 1*/
  Delay_ms(5);
  Transfer_Command_Lcd(0x2E); /*��ѹ���� 2*/
  Delay_ms(5);
  Transfer_Command_Lcd(0x2F); /*��ѹ���� 3*/
  Delay_ms(5);
  Transfer_Command_Lcd(0x22); /*�ֵ��Աȶȣ������÷�Χ 20��27*/
  Transfer_Command_Lcd(0x81); /*΢���Աȶ�*/
  Transfer_Command_Lcd(0x1B); /*΢���Աȶȵ�ֵ�������÷�Χ 0��63*/
  Transfer_Command_Lcd(0xA2); /*1/9 ƫѹ�ȣ�bias��*/
  Transfer_Command_Lcd(0xC8); /*��ɨ��˳�򣺴��ϵ���*/
  Transfer_Command_Lcd(0xA0); /*��ɨ��˳�򣺴�����*/
  Transfer_Command_Lcd(0x40); /*��ʼ�У��ӵ�һ�п�ʼ*/
  Transfer_Command_Lcd(0xAF); /*����ʾ*/
  Lcd_CS_H();
  Clear_Lcd(0);
//  Display_Graphic_8x16(1,0,&Number[0]);
//  Display_Graphic_8x16(2,0,&Number[0]);
//  Display_Graphic_8x16(3,0,&Number[0]);
//  Display_Graphic_8x16(4,0,&Number[0]);
}
/************************************************************************
** �� �� ��:   DisPlayGraphic
** ��������:   ��ʾͼ��
** �������:   dp��ָ��  128*32dots 
** �������:   ��
** �� �� ֵ:   ��	
** ��    ��:   ����
** ��    ��:   2016.10
*************************************************************************/ 
void DisPlayGraphic(unsigned char *dp)
{
  unsigned short i,j;
  for(i=0;i<4;i++)
  {
    Lcd_CS_L();
    Transfer_Command_Lcd(0xB0+i); //set page address,
    Transfer_Command_Lcd(0x10);
    Transfer_Command_Lcd(0x00);
    for(j=0;j<128;j++)
    {
      Transfer_Data_Lcd(*dp);
      dp++;
    }
  }
}
/************************************************************************
** �� �� ��:   Clear_Lcd
** ��������:   ��������
** �������:   flag 1ȫ�� 0ȫ�� 
** �������:   ��
** �� �� ֵ:   ��	
** ��    ��:   ����
** ��    ��:   2016.10
*************************************************************************/ 
void Clear_Lcd(unsigned char flag)
{
  unsigned char i,j,data;
  if(flag)
  {
    data = 0xFF;
  }
  else
  {
    data = 0x00;
  }
  for(i=0;i<4;i++)
  {
    Lcd_CS_L();
    Transfer_Command_Lcd(0xb0+i);
    Transfer_Command_Lcd(0x10);
    Transfer_Command_Lcd(0x00);
    for(j=0;j<132;j++)
    {
      Transfer_Data_Lcd(data);
    }
  }
}
/************************************************************************
** �� �� ��:   Transfer_Command_Lcd
** ��������:   д�������ݵ�LCD
** �������:   data ���� 
** �������:   ��
** �� �� ֵ:   ��	
** ��    ��:   ����
** ��    ��:   2016.10
*************************************************************************/ 
void Transfer_Command_Lcd(unsigned char data)
{
  unsigned char i;
  
  Lcd_CS_L();
  Lcd_RS_L();
  for(i=0;i<8;i++)
  {
    Lcd_SCLK_L();
    //Delay_us(1);
    if(data&0x80) 
    {
      Lcd_SDA_H();
    }
    else 
    {
      Lcd_SDA_L();
    }
    //Delay_us(1);
    Lcd_SCLK_H();
    //Delay_us(1);
    data = data<<1;
  }
}
/************************************************************************
** �� �� ��:   Transfer_Data_Lcd
** ��������:   д��ʾ���ݵ�LCD
** �������:   data ���� 
** �������:   ��
** �� �� ֵ:   ��	
** ��    ��:   ����
** ��    ��:   2016.10
*************************************************************************/ 
void Transfer_Data_Lcd(unsigned char data)
{
  unsigned char i;
  
  Lcd_CS_L();
  Lcd_RS_H();
  for(i=0;i<8;i++)
  {
    Lcd_SCLK_L();
    //Delay_us(1);
    if(data&0x80) 
    {
      Lcd_SDA_H();
    }
    else 
    {
      Lcd_SDA_L();
    }
    //Delay_us(1);
    Lcd_SCLK_H();
    //Delay_us(1);
    data = data<<1;
  }
}
/************************************************************************
** �� �� ��:   Lcd_Address
** ��������:   �趨�Դ��ַ
** �������:   page 1-4 column 
** �������:   ��
** �� �� ֵ:   ��	
** ��    ��:   ����
** ��    ��:   2016.10
*************************************************************************/ 
void Lcd_Address(unsigned char page,unsigned char column)
{
  column = column;
  Transfer_Command_Lcd(0xB0+page-1);           /*����ҳ��ַ*/
  Transfer_Command_Lcd(0x10+(column>>4&0x0F)); /*�����е�ַ�ĸ� 4 λ*/
  Transfer_Command_Lcd(column&0x0F);           /*�����е�ַ�ĵ� 4 λ*/
}
/************************************************************************
** �� �� ��:   Display_Graphic_16x16
** ��������:   ��ʾ16x16�ַ�
** �������:   page 1-4 column 0-127 dp-��ģ
** �������:   ��
** �� �� ֵ:   ��	
** ��    ��:   ����
** ��    ��:   2016.10
*************************************************************************/ 
void Display_Graphic_16x16(unsigned char page,unsigned char column,unsigned char *dp)
{
  unsigned char i,j;
  
  Lcd_CS_L();
  for(j=0;j<2;j++)
  {
    Lcd_Address(page,column);
    for (i=0;i<16;i++)
    {
      Transfer_Data_Lcd(*dp); /*д���ݵ� LCD,ÿд��һ�� 8 λ�����ݺ��е�ַ�Զ��� 1*/
      dp ++;
    }
    page ++;
  }
  Lcd_CS_H();
}
/************************************************************************
** �� �� ��:   Display_Graphic_8x16
** ��������:   ��ʾ8x16�ַ�
** �������:   page 1-4 column 0-127 dp-��ģ
** �������:   ��
** �� �� ֵ:   ��	
** ��    ��:   ����
** ��    ��:   2016.10
*************************************************************************/ 
void Display_Graphic_8x16(unsigned char page,unsigned char column,unsigned char *dp)
{
  unsigned char i,j;
  
  Lcd_CS_L();
  for(j=0;j<2;j++)
  {
    Lcd_Address(page,column);
    for (i=0;i<8;i++)
    {
      Transfer_Data_Lcd(*dp); /*д���ݵ� LCD,ÿд��һ�� 8 λ�����ݺ��е�ַ�Զ��� 1*/
      dp ++;
    }
    page ++;
  }
  Lcd_CS_H();
}
/************************************************************************
** �� �� ��:   Display_Number_8x16
** ��������:   ��ʾ8x16�ַ�
** �������:   page 1-4 column 0-127 num-��ʾ���ݱ��
** �������:   ��
** �� �� ֵ:   ��	
** ��    ��:   ����
** ��    ��:   2016.10
*************************************************************************/ 
void Display_Number_8x16(unsigned char page,unsigned char column,unsigned char num)
{
  Display_Graphic_8x16(page,column,&Number[num*16]);
}
/************************************************************************
** �� �� ��:   Display_Graphic_5x7
** ��������:   ��ʾ5x7�ַ�
** �������:   page 1-4 column 0-127 dp-��ģ
** �������:   ��
** �� �� ֵ:   ��	
** ��    ��:   ����
** ��    ��:   2016.10
*************************************************************************/ 
void Display_Graphic_5x7(unsigned char page,unsigned char column,unsigned char *dp)
{
  unsigned char col_cnt;
  
  Lcd_CS_L();
  Lcd_Address(page,column);
  for (col_cnt=0;col_cnt<8;col_cnt++)
  {
    Transfer_Data_Lcd(*dp);
    dp ++;
  }
  Lcd_CS_H();
}
